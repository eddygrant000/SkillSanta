
name="SkillSanta"

def hello():
    print("Hi all from hello function and web module")

def eddygrant():
    print("Hi from Eddy Grant")