This is a sample distributing module
you can use two funcion from web module

example:
    hello():
    outout: 
        Hi from hello function

    eddygrant():
    outout:
        hi from Eddy Grant